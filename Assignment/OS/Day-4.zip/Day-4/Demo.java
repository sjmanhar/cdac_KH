class ABC
{
    void ADD()
    {
        
    }

}
class XYS
{
    
}
class PQR
{
    
}