ls
cat abc.txt
cal
